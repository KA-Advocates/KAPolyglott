// ==UserScript==
// @name KAPolyglott
// @include http://*.khanacademy.org
// @include https://*.khanacademy.org
// ==/UserScript==

